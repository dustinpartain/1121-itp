# ITP Week 2 Day 3 (In-Class) Practice
my_movies = ["The Godfather", "Ace Ventura", "Gigli", "Die Hard"]

new_releases = ["Encino Man", "I know what you did last Summer", "Phantom Menace"]

#Create a function defined as "movie_listing" which takes one parameter, called "movies".  Write a function that will loop through a list and print out each item.  Then call that function, passing it the my_movies list as an argument.

#Define a function called "update_movies" that will loop through a list parameter, and use the insert() method on each item to the my_movies list.  Call that function using the new_releases list as the argument.  Then call the movie_listing function passing the "new_releases" as the argument.  It should print the updated list.
