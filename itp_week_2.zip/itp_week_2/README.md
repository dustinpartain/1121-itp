# Introduction to Python Week 2

## This Week's Course Content
- Dictionary
- Tuples
- Sets
- Functions
- Scope
- Modularity


## Resources
- 101++ Free Python Books
- Python for Non-Programmers
- W3 Python Tutorial
- Python.land