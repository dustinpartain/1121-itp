#An empyt python file for taking notes, running live code, etc
